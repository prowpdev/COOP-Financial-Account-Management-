<?php

declare(strict_types=1);

namespace App\Models;

use PDO;

class DocumentModel
{
    protected const TABLE = 'user_documents';

    public function __construct(private PDO $db)
    {
    }

    /**
     * Get documents for a specific user, optionally verifying against branch
     */
    public function forUser(string $userId, ?string $branchId = null): array
    {
        $sql = "
            SELECT ud.doc_key, ud.document_data, ud.notes
            FROM user_documents ud
            INNER JOIN users u ON ud.user_id = u.id
            WHERE ud.user_id = :user_id
        ";
        $params = ['user_id' => $userId];

        if ($branchId && $branchId !== 'all') {
            $sql .= " AND u.branch_id = :branch_id";
            $params['branch_id'] = $branchId;
        }

        $sql .= " ORDER BY ud.doc_key ASC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);

        $documents = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $document = json_decode($row['document_data'], true, 512, JSON_THROW_ON_ERROR);
            if (!is_array($document)) {
                $document = [];
            }
            $document['notes'] = $row['notes'];
            $documents[$row['doc_key']] = $document;
        }

        return $documents;
    }

    /**
     * Get user documents based on current_user branch, returning enriched user details
     */
    public function forBranch(?string $branchId = null, ?string $userId = null, ?string $search = null): array
    {
        $sql = "
            SELECT ud.user_id, ud.doc_key, ud.document_data, ud.notes,
                   u.username, u.full_name AS user_name, u.email AS user_email,
                   u.role_id, u.branch_id,
                   b.name AS branch_name,
                   r.name AS role_name
            FROM user_documents ud
            INNER JOIN users u ON ud.user_id = u.id
            LEFT JOIN branches b ON u.branch_id = b.id
            LEFT JOIN user_roles r ON u.role_id = r.id
            WHERE 1=1
        ";
        $params = [];

        if ($branchId && $branchId !== 'all') {
            $sql .= " AND u.branch_id = :branch_id";
            $params['branch_id'] = $branchId;
        }

        if ($userId) {
            $sql .= " AND ud.user_id = :user_id";
            $params['user_id'] = $userId;
        }

        if ($search) {
            $sql .= " AND (u.full_name LIKE :search OR u.username LIKE :search OR ud.doc_key LIKE :search)";
            $params['search'] = "%$search%";
        }

        $sql .= " ORDER BY u.full_name ASC, ud.doc_key ASC";

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);

        $results = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $docData = json_decode($row['document_data'], true, 512, JSON_THROW_ON_ERROR);
            if (!is_array($docData)) {
                $docData = [];
            }
            $docData['notes'] = $row['notes'];
            $docData['user_id'] = $row['user_id'];
            $docData['doc_key'] = $row['doc_key'];
            $docData['user'] = [
                'id' => $row['user_id'],
                'username' => $row['username'],
                'name' => $row['user_name'],
                'full_name' => $row['user_name'],
                'email' => $row['user_email'],
                'branch_id' => $row['branch_id'],
                'branch_name' => $row['branch_name'] ?? 'Main Branch',
                'role_name' => $row['role_name'] ?? 'Staff',
            ];
            $results[] = $docData;
        }

        return $results;
    }

    public function save(string $userId, string $docKey, array $document, ?string $notes): void
    {
        $stmt = $this->db->prepare('
            INSERT INTO user_documents (user_id, doc_key, document_data, notes)
            VALUES (:user_id, :doc_key, :document_data, :notes)
            ON DUPLICATE KEY UPDATE
                document_data = VALUES(document_data),
                notes = VALUES(notes)
        ');
        $stmt->execute([
            'user_id' => $userId,
            'doc_key' => $docKey,
            'document_data' => json_encode(
                $document,
                JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
            ),
            'notes' => $notes,
        ]);
    }

    public function delete(string $userId, string $docKey): bool
    {
        $stmt = $this->db->prepare(
            'DELETE FROM user_documents WHERE user_id = ? AND doc_key = ?'
        );
        $stmt->execute([$userId, $docKey]);
        return $stmt->rowCount() > 0;
    }
}
